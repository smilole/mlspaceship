python -m spaceshiptitanichits.module train --dataset "/path/to/train/data.csv - train
python -m spaceshiptitanichits.module predict --dataset "/path/to/test/data.csv - predict